module.exports = () => ({ replyWithMarkdown }) => replyWithMarkdown(
  '*Available Commands*\n' +
  '/help _Show this help message_\n' +
  '/settings _Show settings_\n' +
  '/about _Show info about the bot_\n' +
  '/bible _Show info about a bible or show a list of all bibles_\n\n' +
  '_More commands comming soon_'
)
