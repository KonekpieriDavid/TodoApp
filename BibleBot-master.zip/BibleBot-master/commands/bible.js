module.exports = () => ctx => {
  const text = '🚧 command is under development 🏗'
  ctx.reply(text)
}
