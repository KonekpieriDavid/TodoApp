﻿using System.Threading.Tasks;

namespace PaymentPlatformV2.Data
{
    public interface IUsersData
    {
        Task InsertUsers(UserloginModel UserLogin);
       /* Task PostUsers(UserloginModel userlogin); */
       /* Task PostUsers(UserloginModel userloginModel, object userlogin); */
    }
}