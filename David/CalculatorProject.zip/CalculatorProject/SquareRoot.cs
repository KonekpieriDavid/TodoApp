﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CalculatorProject
{
     class SquareRoot
    {
     public static Double sqrt(Double firstnumber)
        {
            return Math.Sqrt(firstnumber);
        }
        public static Double sqrt(int firstnumber)
        {
            return Math.Sqrt(firstnumber);
        }

       
    }
}
